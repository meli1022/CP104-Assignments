"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""
total_Sales = int(input("Enter the total amount of sales:"))
ANNUAL_PROFIT = 0.23
profit = total_Sales * ANNUAL_PROFIT

print ("\tProjected Profit Report \n\t-------------------------\n\tTotal Sales: {}\n\tAnnual profit: % 23\n\t-------------------------\n\tProfit: ${}".format(total_Sales,profit))


             
