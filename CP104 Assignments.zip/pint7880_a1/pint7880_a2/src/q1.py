"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""

firstName = input("Enter First Name:")
lastName = input("Enter Last Name:")
print("Welcome {} {}".format(firstName, lastName))


