"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""

P = int(input("Principal:"))
r = float(input("Interest (decimal):"))
t = int(input("Number of years:"))
n = int(input("Compound interest per year:"))

A = P * (((1 + (r/n)) ** (n*t)))

print("Balance: ${:.2f}".format(A))