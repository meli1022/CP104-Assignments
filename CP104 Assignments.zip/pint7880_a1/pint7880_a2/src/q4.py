"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""
date = int(input ("Enter a date in the format MMDDYYYY:"))

month = date // 1000000

date -= month * 1000000 
day = date // 10000

date -=day * 10000
year = date;

print ("{:02}/{:02}/{:04}".format (day,month, year))

