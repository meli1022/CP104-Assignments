"""
------------------------------------------------------------------------
Question 14
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-27"
------------------------------------------------------------------------
"""

MILK = 4 / 6 
BUTTER = 8 / 6 
FLOUR = 0.5 / 6 
SALT = 2 / 6

servings = int(input("Enter servings of Mac and Cheese requires:"))

milk_needed = MILK * servings 
butter_needed = BUTTER * servings
flour_needed = FLOUR * servings
salt_needed = SALT * servings

print ("{} servings of Mac & Cheese requires:".format(servings))


print ("milk (cups): {:.2f}".format(milk_needed))
print ("butter (tablespoons): {:.2f}".format(butter_needed))
print ("flour (cups): {:.2f}".format(flour_needed))
print ("salt (teaspoons): {:.2f}".format(salt_needed))
