"""
------------------------------------------------------------------------
Question 6
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-27"
------------------------------------------------------------------------
"""

p = int(input ("Mortgage principal ($):"))

years = int (input ("Number of years:"))

yearly_interest_rate = float(input ("Yearly interest rate (%):"))

n = years * 12 

i = yearly_interest_rate / 12 / 100

m = p * (i * (1 + i)**(n))/((1 + i)**(n) - 1)

print ("The monthy payments are: $ {:,.2f}".format(m))


