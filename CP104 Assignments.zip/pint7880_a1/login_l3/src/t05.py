"""
------------------------------------------------------------------------
Question 5
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-27"
------------------------------------------------------------------------
"""

hourly_rate = float(input("Hourly rate of pay: $"))

hours_worked = float(input("Hours worked in the week:"))

total_pay = hourly_rate * hours_worked 

print ("Total pay for the week: ${:,.2f}".format(total_pay))

