"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-27"
------------------------------------------------------------------------
"""
FREEZING = 32
fahrenheit = int (input ("Temperature (F):"))


celsius = int((fahrenheit - FREEZING) * 5/9)

print ("Temperature (C): {:.0f}".format(celsius))


