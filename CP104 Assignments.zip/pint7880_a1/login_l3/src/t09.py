"""
------------------------------------------------------------------------
Question 9
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-27"
------------------------------------------------------------------------
"""
PI = 3.14
diameter = float(input("Diameter of container base (cm):"))
height = float (input("Height of container (cm):"))
cost_of_material = float(input("Cost of material ($/cm^2):"))
number_of_containers = int(input("Number of containers:"))

surface_area = PI * (diameter/2)**(2) + 2 * PI *(diameter/2)*height

one_container = surface_area * cost_of_material

print ("The cost of one container is: $ {:,.2f}".format(one_container))

total_cost = one_container * number_of_containers

print ("The total cost of all containers is:  $ {:,.2f}".format(total_cost))


