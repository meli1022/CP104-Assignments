"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-07"
------------------------------------------------------------------------
"""
import a7_functions


list1 = a7_functions.win_game()

green_output = list1.count("green")
red_output = list1.count("red")
    
print("""Number of "red" entered:{}""".format(red_output))
print("""Number of "green" entered:{}""".format(green_output))
    
if green_output>red_output:
    print("""green" team wins!!!""")
elif green_output<red_output:
    print(""""red" team wins!!!""")
else:
    print("tie")
        


