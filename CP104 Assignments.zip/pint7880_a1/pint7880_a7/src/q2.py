"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-08"
------------------------------------------------------------------------
"""
import a7_functions

num_lines = int(input("Enter number of lines:"))

output = a7_functions.dispay_pattern(num_lines)

