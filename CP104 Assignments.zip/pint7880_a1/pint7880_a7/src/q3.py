"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-08"
------------------------------------------------------------------------
"""
import a7_functions

list1 = a7_functions.keep_positive_numbers()

print("List entered:{}".format(list1))


