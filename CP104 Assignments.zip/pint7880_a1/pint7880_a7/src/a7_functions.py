"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-07"
------------------------------------------------------------------------
"""


def win_game():
    
    """

    -------------------------------------------------------

    Asks the user to enter a series of strings and returns
    two numbers representing how many times the string "red"
    appeared in the input and how many times the string
    "green" appeared in the input.

    Use: win_game()

    -------------------------------------------------------

    Parameters:

        None

    Returns

        list1 -  a list of all user's inputs
    
    Loop used to validate input:
    I used a "if-elif-else" loop to validate the input of the
    user so that I can determine which statement should be printed. 

    -------------------------------------------------------

    """
    
    inputs = input("""Enter "red" or "green" or press ENTER to stop: """)
    list1=[]
    
    list1.append(inputs)
    
    while inputs != "":
        inputs = input("""Enter "red" or "green" or press ENTER to stop:""")
        
        for i in range(1):
            list1.append(inputs)
            
    return list1

def dispay_pattern(num_lines):
    
    """

    -------------------------------------------------------

    Takes one parameter for the size of the triangle and
    displays a triangular pattern.

    Use: dispay_pattern(num_lines)

    -------------------------------------------------------

    Parameters:

        num_lines - input from the user (int>0)

    Returns

        None 

    -------------------------------------------------------

    """
    
    print("#")
    for i in range(1,num_lines -1):
        print("#", end = '')
        for j in range(1,i):
            print(" ", end='')
        print("#")
    for i in range(0,num_lines):
        print("#", end='')
    return

def keep_positive_numbers():
    
    
    """

    -------------------------------------------------------

    Asks the user for a series of numbers and returns only
    the positive integers.

    Use: keep_positive_numbers()

    -------------------------------------------------------

    Parameters:

       None
       
    Returns

        list1 - list of all positive integers the user entered

    -------------------------------------------------------

    """
    
    inputs = input("Enter a positive integer:")
    list1=[]
    
    if inputs.isdigit() == True:
        
        list1.append(inputs)
            
    while inputs != "0":
        inputs = input("Enter a positive integer:")
        
        if inputs.isdigit() == True:
            list1.append(inputs)
    
    return list1
        
def find_value(num_list, target):
    
    """

    -------------------------------------------------------

    Finds the locations of a target value in a list

    Use: find_value(num_list, target)

    -------------------------------------------------------

    Parameters:

       num_list - list of all positive integers the user entered
       
       target - input from the user (int>0)
       
    Returns

        target_list - list of all locations the target is in the list

    -------------------------------------------------------

    """
    
    target_list = []
     
    for x in range(len(num_list)):
        if target == num_list[x]:
            target_list.append(x)
            
    return target_list
        
   
     
    
        