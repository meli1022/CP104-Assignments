"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-08"
------------------------------------------------------------------------
"""

import a7_functions

num_list = a7_functions.keep_positive_numbers()

target = input("Enter target = ")


print("List entered:{}".format(num_list))

output = a7_functions.find_value(num_list, target)

print("Target exists at location(s): {}".format(output))










