"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""

def customer_record(fv, n):
    """
    -------------------------------------------------------
    Find the n-th record in a comma-delimited sequential file.
    Records are numbered starting with 0.
    Use: result = customer_record(fv, n)
    -------------------------------------------------------
    Parameters:
        fv - file to search (file - open for reading)
        n - the number of the record to return (int > 0)
    Returns:
        result - a list of the fields of the n-th record if it exists,
            an empty list otherwise (list)
    -------------------------------------------------------
    """
    
    result = []

    line = fv.readline()
    i=0
    while line != "":
        result.append(line.strip())
        line = fv.readline()
        i +=1
    if i >n:    
        result = result[n].strip().split(",")
    else:
        result =[]
    
    return result

def customer_best(fv):
    """
    -------------------------------------------------------
    Find the customer with the largest balance.
    Assumes file is not empty.
    Use: result = customer_best(fv)
    -------------------------------------------------------
    Parameters:
        fv - file to search (file - open for reading)
    Returns:
        result - the record with the greatest balance (list)
    -------------------------------------------------------
    """
    

    line = fv.readline()
    result = line.strip().split(",")
    line = fv.readline()
    
    while line != "":
        
        line = line.strip().split(",")
       
        if float(result[3]) < float(line[3]):
            result = line
        line = fv.readline()
     
    return result
    
def append_increment(fv):
    """
    -------------------------------------------------------
    Appends a number to the end of the fv. The number appended
    is the last number in the file plus 1.
    Assumes file is not empty.
    Use: num = append_increment(fv)
    -------------------------------------------------------
    Parameters:
        fv - file to search (file - open for reading/writing)
    Returns:
        num - the number appended to the file (int)
    ------------------------------------------------------
    """
    
    
    line = fv.readline()
    
    while line != "":
        num = line.strip()
        line = fv.readline()
        
    num = int(num) + 1
    fv.write("\n{}".format(str(num)))
    
    return num 
        
def count_frequency_value(fv, value):
    """
    -------------------------------------------------------
    Counts the number of appearances of value in fv.
    Use: count = count_frequency_value(fv, value)
    -------------------------------------------------------
    Parameters:
        fv - file to search (file - open for reading)
        value - the value to count (int)
    Returns:
        count - the number of appearance of value in fv (int)
    ------------------------------------------------------
    """
    line = fv.readline()
    counter = 0
    
    while line != "":
        line = line.strip()
        line = fv.readline()
       
        if value == int(line):
            counter += int(line)
            
     
    return counter

def file_copy_n(fv_1, fv_2, n):
    """
    -------------------------------------------------------
    Copies n record from fv_1 (starting from the beginning of the file) to fv2
    Use: file_copy_n(fv_1, fv_2, n)
    -------------------------------------------------------
    Parameters:
        fv_1 - file to search (file - open for reading)
        fv_2 - file to search (file - open for appending)
    Returns:
        None
    ------------------------------------------------------
    """
    
    
    
    