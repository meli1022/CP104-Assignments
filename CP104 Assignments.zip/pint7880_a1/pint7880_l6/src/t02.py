"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-25"
------------------------------------------------------------------------
"""
import functions

num = int(input("Enter a number:"))
total = functions.sum_odd(num)

print ("The sum of all odd numbers from 1 to {} is: {}".format(num,total))
