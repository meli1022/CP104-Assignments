"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-14"
------------------------------------------------------------------------
"""

def sum_digit_string(my_str):
    

    """
    -------------------------------------------------------
    Sums all the digits in my_str, ignores non-digit characters
    Use: total = sum_digit_string (my_str) 
    -------------------------------------------------------
    Parameters: 
        my_str: string that has single-digit numbers (str) 
    Returns:
        total: sum of all the single digit number (integer >= 0)
    -------------------------------------------------------
    """

    total = 0

    for i in range(len(my_str)):
        if my_str[i].isdigit():
            total += int(my_str[i])
        elif my_str == "":
            total = None
        
    return total

def find_frequent(my_str):
    
    """
    -------------------------------------------------------
    Takes one parameter and finds the character that appears most frequently
    Use: total = find_frequent(my_str)
    -------------------------------------------------------
    Parameters: 
        my_str: user's string input (str) 
    Returns:
        character: the character that appears most frequently (str)
    -------------------------------------------------------
    """
    
    maximum = 0

    for i in my_str:
        counter = my_str.count(i)
        if counter > maximum:
            maximum = my_str.count(i)
            character = i
        elif my_str == "":
            character = None
        
    return character


def string_capitalizer(my_str):
    
    """
    -------------------------------------------------------
    Takes a string and returns a new string that has a copy
    of the string where the first letter of each sentence is capitalized.
    Use: total = find_frequent(my_str)
    -------------------------------------------------------
    Parameters: 
        my_str: user's string input (str) 
    Returns:
        newstr: the new string with changes made (str)
    -------------------------------------------------------
    """

    newStr = ''
    capital = True
    for i in my_str:
        if i == "?" or i == ".":
            newStr+=i
            capital = True
            
        elif capital == True and i.isalpha():
            capital = False
            newStr+=i.upper()
        elif my_str == "":
            newStr = None
        else:
            newStr+=i
        
    return newStr
    
def is_word_chain(my_list):
    
    """
    -------------------------------------------------------
    Takes a list of words and returns True if the list contains
    a word chain and False otherwise.
    Use: total = find_frequent(my_str)
    -------------------------------------------------------
    Parameters: 
        my_list: user's list input (list) 
    Returns:
        chain: true or false if the list is a chain (boolean)
    -------------------------------------------------------
    """
    
    chain = True
    for i in range(len(my_list)-1):
        if my_list[i][-1].lower() != my_list[i+1][0].lower():
            chain = False
        
    return chain
   
    