"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-14"
------------------------------------------------------------------------
"""

import a8_functions



my_str=input("Enter a sentence/sentences:")

output = a8_functions.string_capitalizer(my_str)

print(output)
    