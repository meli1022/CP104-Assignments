"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-14"
------------------------------------------------------------------------
"""
import a8_functions

my_str = input("Enter a string:")

character = a8_functions.find_frequent(my_str)

print("The most frequent character is: {}".format(character))
