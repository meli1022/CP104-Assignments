"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-14"
------------------------------------------------------------------------
"""

import a8_functions

my_str = input("Enter a string of single digit numbers:")

total = a8_functions.sum_digit_string(my_str)

print("The sum of all single digit numbers is: {}".format(total))

