"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-16"
------------------------------------------------------------------------
"""

import a8_functions


n = input("Enter a string separated by comma:")

my_list = n.split(",")


output = a8_functions.is_word_chain(my_list)

print(output)
