"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-29"
------------------------------------------------------------------------
"""

def add_matrices(list1, list2):
    
    """
    -------------------------------------------------------
    Adds matrices
    Use: add_matrices(list1, list2)
    -------------------------------------------------------
    Parameters:
    Returns
    -------------------------------------------------------
    """
    
    result = [[0,0,0], 
        [0,0,0]] 
    
    for i in range(len(list1)):    
        for j in range(len(list1[0])): 
            result[i][j] = list1[i][j] + list2[i][j] 

    return result

def largest_even(mylist):
    
    """
    -------------------------------------------------------
    largest even number in 2d list
    Use: largest_even(mylist)
    -------------------------------------------------------
    Parameters:
    Returns
    -------------------------------------------------------
    """
    
    even=[]
    for x in mylist:
        for y in x:
            if y%2==0:
                even.append(y)
    
    maximum=even[0]
    for z in even:
        if z>maximum:
            maximum=z
            
    if mylist==[]:
        maximum = 1
        
    return maximum    

def word_freq(word_list):
    
    """
    -------------------------------------------------------
    Calculates the frequency of each word in the string and puts it in a dictionary
    Use: word_freq(word_list)
    -------------------------------------------------------
    Parameters:
    Returns
    -------------------------------------------------------
    """

    freq = []
        
    for w in word_list:
        freq.append(word_list.count(w))
        zipped = zip(word_list, freq)
        dictionary = dict(zipped)
        
    if len(word_list) == 0:
        dictionary = {}
        
    return dictionary

