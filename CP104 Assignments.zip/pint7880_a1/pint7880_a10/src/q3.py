"""
------------------------------------------------------------------------
question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-30"
------------------------------------------------------------------------
"""
import a10_functions

word_string= input("String:")

word_list = word_string.split()

dictionary = a10_functions.word_freq(word_list)

print (dictionary)

