"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""

def sum_numbers(file):
    
    """
    -------------------------------------------------------
    Reads through this text file and returns a list of the 
    numbers encountered and their sum
    
    Use: numbers, total = sum_numbers(file)
    -------------------------------------------------------
    Parameters: 
        file: text file 
    Returns:
        total
        numbers
    -------------------------------------------------------
    """
    
    numbers = []
    total = 0
    line = file.readline().split(" ")
    while line != '':
        for i in range (len(line)):
            if line[i].isdigit():
                digit = int(line[i])
                numbers.append(line[i])
                total += digit
            else:
                None
        return numbers,total
    
    

def find_median(file):
    
    """
    -------------------------------------------------------
    Finds the median of a group of scores
    
    Use: median, numbers = find_median(file)
    -------------------------------------------------------
    Parameters: 
        file: text file 
    Returns:
        median
        numbers
    -------------------------------------------------------
    """
    
    numbers = []
    median = -1
    
    for line in file:
        for x in line.split():
            if(x.isdigit()):
                numbers.append(int(x))
            else:
                None
           
    numbers = sorted(numbers)
    
    length = len(numbers)
    if (length % 2 == 0):
        median = numbers[length // 2]+ numbers
    else:
        median = numbers[length // 2]
        
    return median, numbers

def analysis_file(file):
    
    """
    -------------------------------------------------------
    Takes a file and returna a list of number of uppercase
    letters in the file, lowercase letters in the file, 
    digits in the file, whitespace characters in the file
    
    Use: numbers, total = sum_numbers(file) 
    -------------------------------------------------------
    Parameters: 
        file: text file 
    Returns:
        upper
        lower
        digits
        whitespaces
    -------------------------------------------------------
    """
    
    upper = 0
    lower = 0
    digits = 0
    whitespaces = 0
    
    for line in file:
        for x in line:
            if (x.isupper()):
                upper += 1
            elif (x.islower()):
                lower += 1
            elif (x.isdigit()):
                digits +=1
            elif (x.isspace()):
                whitespaces +=1
    return upper, lower, digits, whitespaces
    
    

        
def valid_sn(txt_srl):
    
    """
    -------------------------------------------------------
    Takes a string as a parameter and returns True or False
    f the serial number is valid or invalid
    
    Use: result = valid_sn(txt_srl)
    -------------------------------------------------------
    Parameters: 
        txt_srl: text file 
    Returns:
        result
    -------------------------------------------------------
    """
    
    result = True
    if txt_srl.startswith("SN/"):
        nums = txt_srl[3:].rstrip().split('-')
        if(len(nums) == 2):
            pt_1 = nums[0]
            pt_2 = nums[1]
            if(not pt_1.isdigit() or len(pt_1) != 4 or not pt_2.isdigit() or len(pt_2) != 3):
                result = False
        else:
            result = False
    else:
        result = False
    return result
    
def valid_sn_file(txt_srl, output_valid, output_invalid):
        
    for line in txt_srl:
        if (valid_sn(line)):
            output_valid.write(line)
        else:
            output_invalid.write(line)
        
                
                
                
    
