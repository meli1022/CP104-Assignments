"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""

import a9_functions

file = open("numbers.txt", "r+" ,encoding="utf-8")

output_file = open("output_q2.txt", "w" ,encoding="utf-8")

median, numbers = a9_functions.find_median(file)

output_file.write("{}={}".format(numbers,median))


file.close()
output_file.close()