"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""

import a9_functions



txt_srl = open("serial_number.txt", "r")

output_valid = open("output_valid.txt", "w" ,encoding="utf-8")
output_invalid = open("output_invalid.txt", "w" ,encoding="utf-8")

a9_functions.valid_sn_file(txt_srl, output_valid, output_invalid)

txt_srl.close()
output_valid.close()
output_invalid.close()