"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""

import a9_functions

file = open("text.txt", "r+" ,encoding="utf-8")

output_file = open("output_q3.txt", "w" ,encoding="utf-8")

upper,lower,digits,whitespaces = a9_functions.analysis_file(file)
output_file.write("{},{},{},{}".format(upper,lower,digits,whitespaces))

file.close()
output_file.close()