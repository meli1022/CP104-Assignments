"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""
import a9_functions

file = open("text_numbers.txt", "r+" ,encoding="utf-8")

output_file = open("output_q1.txt", "w" ,encoding="utf-8")

numbers,total = a9_functions.sum_numbers(file)

text = "["
for i in range(len(numbers)-1):
    text+= str(numbers[i]) + "+" 
text += str(numbers[-1]) 
text += "]="+ str(total)

output_file.write(text)

file.close()
output_file.close()