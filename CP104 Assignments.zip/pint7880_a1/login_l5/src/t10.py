"""
------------------------------------------------------------------------
Question 10
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""

import functions

intensity = float(input("Richter Scale Number:"))

result = functions.richter(intensity)

print (result)