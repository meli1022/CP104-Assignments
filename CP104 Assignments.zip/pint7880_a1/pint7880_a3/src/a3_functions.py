"""
------------------------------------------------------------------------
Assignment 3 Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-26"
------------------------------------------------------------------------
"""

def calorie_calculator (fat_grams,carb_grams):
    
    """
    -------------------------------------------------------
    Converts calories for two gram values
    Use: total_cals = fat_cals + carb_cals
    -------------------------------------------------------
    Parameters:
        fat_grams - The amount of grams of fat consumed(float>=)
        carb_grams - The amount of grams of carbohydrates consumed (float>=0)
    Returns
        fatcals - The amount of fat calories consumed (float >= 0)
        carbscals - The amount of carbohydrate calories consumed (float >= 0)
    -------------------------------------------------------
    """

    
    fat_cals = fat_grams * 9
    carb_cals = carb_grams * 4
    return fat_cals, carb_cals

    