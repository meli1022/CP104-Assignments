"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-24"
------------------------------------------------------------------------
"""

balloon_Number = int(input("Enter number of balloons:"))
children_Number = int (input("Enter number of children:"))

balloons_Per_Person =  int(balloon_Number / children_Number)
extra_Balloons = int(balloon_Number - (children_Number * balloons_Per_Person))

print ("Each child will receive {} balloons".format(balloons_Per_Person))
print ("Balloons that won't be distributed: {}". format(extra_Balloons))