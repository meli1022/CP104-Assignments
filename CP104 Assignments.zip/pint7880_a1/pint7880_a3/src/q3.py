"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-26"
------------------------------------------------------------------------
"""
integers = int (input("Enter a positive two digit integer:"))
first_Num = integers//10
second_Num = integers%10
sum_Of_Integers = first_Num + second_Num

print ("The sum of the two digits in the integer ({}) is: {}".format(integers, sum_Of_Integers))