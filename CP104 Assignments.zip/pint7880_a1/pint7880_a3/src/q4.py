"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-26"
------------------------------------------------------------------------
"""
import a3_functions

fat_grams = float(input("Enter the fat grams consumed: "))
carb_grams = float (input("Enter the carbohydrate grams compound:"))

fat_cals, carb_cals = a3_functions.calorie_calculator(fat_grams, carb_grams)
total_cals = fat_cals + carb_cals

print ("Total calories a total of {:.2f} [Fat calories:{:.2f} and Carb calories: {:.2f}]".format(total_cals, fat_cals,carb_cals))
