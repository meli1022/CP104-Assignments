"""
------------------------------------------------------------------------
Question 3 Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""


def num_day(day_int):
    
    """
    -------------------------------------------------------

    Takes an integer in the range of 1 through 7 and returns
    a string representing the corresponding day of the week

    Use: num_day(day_int)

    -------------------------------------------------------

    Parameters:

        day_int - integer user inputs (int 1-7)

    Returns

        day_Of_Week - string of the day of the week 
        ("Monday","Tuesday","Wednesday","Thursday","Friday",
        "Saturday", "Sunday")

    -------------------------------------------------------

    """
    
    if day_int == 1:
        day_Of_Week = "Monday"
        return day_Of_Week
    elif day_int == 2:
        day_Of_Week = "Tuesday"
        return day_Of_Week
    elif day_int == 3:
        day_Of_Week = "Wednesday"
        return day_Of_Week
    elif day_int == 4:
        day_Of_Week = "Thursday"
        return day_Of_Week
    elif day_int == 5:
        day_Of_Week = "Friday"
        return day_Of_Week
    elif day_int == 6:
        day_Of_Week = "Saturday"
        return day_Of_Week
    elif day_int == 7:
        day_Of_Week = "Sunday"
        return day_Of_Week
   
    
    
    
    
    