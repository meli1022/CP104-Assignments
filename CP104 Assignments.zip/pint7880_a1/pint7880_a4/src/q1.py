"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-03"
------------------------------------------------------------------------
"""
    
import q1_functions


income = float(input ("Enter your income: $"))
               
tax_Liability = q1_functions.calc_federal_tax(income) + q1_functions.calc_prov_tax(income)

federal_Tax = q1_functions.calc_federal_tax(income)
provincial_Tax = q1_functions.calc_prov_tax(income)

print ("Your tax liability is: $ {:.0f}". format(tax_Liability))
print ("[details federal tax: $ {:.0f}, state tax: $ {:.0f}]".format(federal_Tax, provincial_Tax))






