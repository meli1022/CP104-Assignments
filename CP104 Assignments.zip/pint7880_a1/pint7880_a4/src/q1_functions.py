"""
------------------------------------------------------------------------
Question 1 Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-03"
------------------------------------------------------------------------
"""
# for federal
OVER = .35
BETWEEN = .25
BELOW = .15

# for provincial
PROVINCIAL_OVER = 0.05


def calc_federal_tax(income):
    
    """

    -------------------------------------------------------

    Calculates the federal tax based on income

    Use: federal_Tax = calc_federal_tax(income)

    -------------------------------------------------------

    Parameters:

        income - annual income of tax payer (float >=100000)

    Returns

        federal_Tax - how much a taxpayer pays in federal tax (float)

    -------------------------------------------------------

    """
    first_Tax_Bracket = (35000) * BELOW
    second_Tax_Bracket = (100000 - 35001) * BETWEEN
    third_Tax_Bracket = (income - 100000) * OVER
    federal_Tax = first_Tax_Bracket + second_Tax_Bracket + third_Tax_Bracket
    return federal_Tax

def calc_prov_tax(income):
    """

    -------------------------------------------------------

    Calculates the provincial tax based on income

    Use: provincial_Tax = calc_prov_tax(income)

    -------------------------------------------------------

    Parameters:

        income - annual income of tax payer (float >=100000)

    Returns

        provincial_Tax - how much a taxpayer pays in provincial tax (float)

    -------------------------------------------------------

    """
    provincial_Tax = (income -50000) * PROVINCIAL_OVER
   
    return provincial_Tax
    