"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""

from q3_functions import num_day

day_int = int(input ("Please enter a number between 1 and 7:"))

def main():
    
    if day_int >= 1 and day_int <= 7:
        print ("The number {} corresponds to {}.". format(day_int, num_day(day_int)))
        
    else:
        print("Sorry, that is not a valid number.")
        
main();
