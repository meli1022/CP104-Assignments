"""
------------------------------------------------------------------------
Question 2 Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-03"
------------------------------------------------------------------------
"""
import random

def math_quiz():
    """

    -------------------------------------------------------

    Display two random integers (0-999) that are to be added

    Use: math_quiz()

    -------------------------------------------------------

    Parameters:

        a - first random number (int 0-999)
        b - second random number (int 0-999)

    Returns

        actual_sum - sum of a and b (int)

    -------------------------------------------------------

    """
    
    a = random.randint(0,1000)
    b = random.randint(0,1000)
    print(" {}".format(a))
    print("+ {}".format(b))
    print("")
    actual_sum = a + b
    user_sum = int (input ("Answer: "))
    print("")

    if user_sum == actual_sum:
        print ("Congratulations, correct answer!")
    else: 
        print ("Incorrect - the answer should be: {}".format(actual_sum))