"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-15"
------------------------------------------------------------------------
"""
import functions

product_code = input("Enter a product code:")

functions.validate_code(product_code)

