"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""

import functions

base = float(input("Length of base:"))
height = float(input("Perpendicular height of pyramid:"))

sh,a,v = functions.square_pyramid(base, height)

print ("Slant height of square pyramid: {:.2f}".format(sh))
print ("Area of square pyramid: {:.2f}".format(a))
print ("Volume of square pyramid: {:.2f}".format(v))

