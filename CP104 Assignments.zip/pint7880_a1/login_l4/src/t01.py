"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""
import functions

radius = float(input("Enter radius:"))

d = functions.diameter(radius)

print ("Diameter of circle: {:.2f}".format(d))