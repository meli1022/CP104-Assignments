"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-14"
------------------------------------------------------------------------
"""
height_inches = 10
conversion_metres = height_inches * 0.0254

print(height_inches, "inches in height is equivalent to", conversion_metres, "metres.")

