"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-09-14"
------------------------------------------------------------------------
"""

print ('''The book title is, "Learn python in 21 days"''')
print ("What's mine is mine, and what's yours is mine.")
print ('''"You have enemies? Good. That means you've stood up for 
something, sometime in your life." Winston Churchill ''')
print('''Three things cannot be long hidden: the sun, the moon, and 
the truth.''')