"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-25"
------------------------------------------------------------------------
"""
import a6_functions

num = int(input("Enter a positive integer:"))

while num<2:
    num  = int(input("Enter a positive integer:"))
    
prime = a6_functions.is_prime(num)
