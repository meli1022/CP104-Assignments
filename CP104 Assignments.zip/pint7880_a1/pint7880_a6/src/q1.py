"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-22"
------------------------------------------------------------------------
"""
import a6_functions


principal = float(input("Please enter your investment amount: "))
year = int(input("Please enter number of years:"))


print ("Year\tValue (Million Dollars)")
print ("----\t-----------------------")

growth_per_year = a6_functions.calc_profit(principal, year)