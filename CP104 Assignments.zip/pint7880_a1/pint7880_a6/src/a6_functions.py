"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-22"
------------------------------------------------------------------------
"""

GROWTH = 0.05
MILLION = 1000000

def calc_profit(principal,year):
    
    """

    -------------------------------------------------------

    Takes the amount of money to invest and a the number of
    years of investment and calculates and displays the value
    of growth per year

    Use: calc_profit(principal,year)

    -------------------------------------------------------

    Parameters:

        principal - value input from the user (float>0)
        year - value input from the user (int>0)

    Returns

        None

    -------------------------------------------------------

    """
    
    for i in range (1,year+1):
        
        growth_per_year = principal  * GROWTH
        
        principal = (principal + growth_per_year) 
           
        print("   {}\t{:.6f}".format(i, principal/MILLION))
        
    return


        

def perfect_square(num):
    
    """

    -------------------------------------------------------

    Takes a positive integer and prints all the perfect square
    numbers between 1 and the number

    Use: perfect_square(num)

    -------------------------------------------------------

    Parameters:

        num - value input from the user (int>0)

    Returns

        output - returns the perfect square numbers or error message 

    -------------------------------------------------------

    """
    
    if (num>=0):
        output = "Perfect squares below {} are:".format(num)
        i = 1
        while (i <= num):
            if(i**2 < num) and (i != 1):
                output += ", " + str(i**2)
            elif(i**2 < num):
                output += str(i**2)
            i += 1
    else:
        output = "You did not enter a positive integer"
    return output

def factorial(num): 
    
    """

    -------------------------------------------------------

    Takes a positive integer and calculates then prints the
    factorial of that number
    
    Use: perfect_square(num)

    -------------------------------------------------------

    Parameters:

        num - value input from the user (int>0)

    Returns

        None
    -------------------------------------------------------

    """      
    
    factorial = 1
        
    if num < 1:
        print("You did not enter a positive integer")
    else:
        for i in range(1,num + 1):
            factorial = factorial*i
        print("{}! = {}".format(num,factorial))           
                
def is_prime(num):
    
    """

    -------------------------------------------------------

    Takes a positive integer and prints if it is a prime number or not

    Use: is_prime(num)

    -------------------------------------------------------

    Parameters:

        num - value input from the user (int>0)

    Returns

        None

    -------------------------------------------------------

    """
    prime = True
    
    for i in range (2,num):

        if num % i == 0:
            prime = False
        
            
    if prime == True:
        print("{} is a prime number".format(num))
    elif prime == False:
        print("{} is not prime number".format(num))
    return
