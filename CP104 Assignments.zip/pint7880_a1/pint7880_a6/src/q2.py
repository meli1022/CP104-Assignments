"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-25"
------------------------------------------------------------------------
"""
import a6_functions

num = int(input("Enter a positive integer:"))

output = a6_functions.perfect_square(num)

print (output)