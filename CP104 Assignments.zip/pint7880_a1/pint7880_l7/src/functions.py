"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-01"
------------------------------------------------------------------------
"""

def power_of_two(target):
    
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """

    x = 2
    number = 0
    
    power = x ** number
    
    
    while power < target:
       
        power = x ** number
        number += 1
        
    return power

def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    
    power = 2
    base = 0
    
    number = base ** power
    
    
    while  number < target:
        
        base += 1
        
        number += base ** power
        
    return number
    
def num_categories():
    """
    -------------------------------------------------------
    Asks a user to enter a series of numbers, then counts and returns
    how may positives, negatives, and zeroes there are.
    Stop processing values when the user enters -999.
    Use: negatives, zeroes, positives = num_categories()
    -------------------------------------------------------
    Returns:
        negatives - number of negative values (int)
        zeroes - number of zero values (int)
        positives - number of positive values (int)
    ------------------------------------------------------
    """
    value = int(input("First Value:"))
    positives = 0
    negatives = 0
    zeroes = 0
    
    while value != -999:
        
        if value > 0: 
            positives += 1
        elif value < 0: 
            negatives += 1
        else:
            zeroes += 1
    
        value = int(input("Next Value:"))
        
    return  negatives, zeroes, positives
    
def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    ------------------------------------------------------
    """
    
    expense_input = float(input("Enter an expense (0 to quit): $"))
    expenses = 0
    
    while expense_input != 0:
        
        if expense_input > 0: 
            expenses += expense_input
        
        
            
        
            
        expense_input = int(input("Enter another expense (0 to quit): $"))
    balance = available - expenses
        
    if balance < 0:
            status = "Deficit"
    elif balance > 0:
        status = "Surplus"
    else:
        status = "Balanced"
        
    return  expenses, balance, status
    