"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-01"
------------------------------------------------------------------------
"""

import functions



target = int(input("Enter target number: "))

p = functions.power_of_two(target)

print("Sum of squares >= target {} : {}" .format(target, p))