"""
------------------------------------------------------------------------
Question 2 Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-10"
------------------------------------------------------------------------
"""

def pocket_color(num) :
    
    """

    -------------------------------------------------------

    Takes an interger between 0 and 36 and returns the color
    that corresponds to the pocket number

    Use: pocket_color(num)

    -------------------------------------------------------

    Parameters:

        num - user's value input (int)


    Returns

        colour - corresponding pocket colour to value (String)

    -------------------------------------------------------

    """
    
    if num == 0:
        colour = "Green"
        
    elif num <= 10 and num > 0: 
    
        if num %2 != 0:

            colour = "Red"

        elif num %2 == 0:

            colour = "Black"
   
    elif num <= 18 and num > 10:
    
        if num %2 != 0:

            colour = "Black"

        elif num %2 == 0:

            colour = "Red"
      
    elif num > 18 and num <=28 :

        if num %2 != 0:

            colour = "Red"

        elif num %2 == 0:

            colour = "Black"
        
    elif num > 28 and num <=36:

        if num %2 != 0:

            colour = "Black"

        elif num %2 == 0:

            colour = "Red"
    else:
            colour = "ERROR"

    return colour

    


