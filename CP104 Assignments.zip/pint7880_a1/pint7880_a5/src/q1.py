"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-08"
------------------------------------------------------------------------
"""

import a1_functions


x = float(input("Please enter your first number:"))
y = float(input("Please enter your second number:"))
z = float(input("Please enter your third number:"))

average = a1_functions.max_three(x,y,z)

print("The average of the two smaller values is: {:.1f}".format(average))