"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-08"
------------------------------------------------------------------------
"""

def max_three(x,y,z) :
    
    """

    -------------------------------------------------------

    Takes 3 floating values as parameters and returns the
    average of the two smaller values

    Use: max_three(x,y,z)

    -------------------------------------------------------

    Parameters:

        x - first value input (float

        y - second value input (float)

        z - third value input (float)

    Returns

        average - average of the two smallest values (float)

    -------------------------------------------------------

    """
    
    if x > y and x > z:
        average = (y+z) / 2 
    elif y > z:
        average = (x+z) / 2 
    else: 
        average = (x+y)/2
    return average


   

         
    
        
    
    
    
    