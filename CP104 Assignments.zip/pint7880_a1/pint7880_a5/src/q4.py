"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""
import a4_functions

x = int(input ("Enter x coordinate:"))
y = int(input ("Enter y coordinate:"))

quadrant_Number = a4_functions.quadrant(x, y)

print ("The point ({},{}) lies in {} ".format(x,y,quadrant_Number))