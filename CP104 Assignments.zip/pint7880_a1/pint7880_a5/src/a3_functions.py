"""
------------------------------------------------------------------------
Question 3 Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-10"
------------------------------------------------------------------------
"""
FIRST_DISCOUNT = 0.25
SECOND_DISCOUNT = 0.50
THIRD_DISCOUNT = 0.10

price = 0

def base_price(length):
    
    """

    -------------------------------------------------------

    Takes length of call as parameter and returns the base
    price of the call

    Use: base_price(length)

    -------------------------------------------------------

    Parameters:

        length - value input from the user (int)


    Returns

        price - Returns the total price of the call (float>0)

    -------------------------------------------------------

    """

    CHARGE = 0.08
    
    price = length * CHARGE
    
    return price

def time_discount (price, hour):
    
    """

    -------------------------------------------------------

    Takes price and hour of call as parameters and returns
    the price after applying time of placement discount
    
    Use: time_discount (price,hour)

    -------------------------------------------------------

    Parameters:

        length - value input from the user (int)
        price - value of current price (float)

    Returns

        price - Returns the total price of the call (float>0)

    -------------------------------------------------------

    """
  
    if hour >18 and hour <=24:
        price = price * FIRST_DISCOUNT
        
    if hour > 0 and hour <= 8:
        price = price * SECOND_DISCOUNT
        
    return price
    
    
def length_discount(length,price):
    
    """

    -------------------------------------------------------

    Takes price and length of call as parameters and returns
    the price after applying length discount

    Use: length_discount(length,price)

    -------------------------------------------------------

    Parameters:

        length - value of length input from the user (int)
        price - value of current price (float)


    Returns

        price - Returns the total price of the call (float>0)

    -------------------------------------------------------

    """

    if length > 30:
        price = price * THIRD_DISCOUNT
        
    return price
    