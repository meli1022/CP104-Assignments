"""
------------------------------------------------------------------------
Question 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-10"
------------------------------------------------------------------------
"""
import a3_functions

length = int (input("Length of call (minutes): "))
hour = int (input ("Hour of call (24hour format): "))

price = a3_functions.base_price(length)

total_Price = a3_functions.length_discount(length, price)

print ("Total price of call: ${:.2f}".format(total_Price))