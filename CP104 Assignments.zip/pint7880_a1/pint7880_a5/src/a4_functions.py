"""
------------------------------------------------------------------------
Question 4 functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""

def quadrant(x, y): 
    
    """
    -------------------------------------------------------

    Given x and y coordinates of a point as parameters, 
    returns the quadrant to which the point belongs.
    
    Use: quadrant(x,y)

    -------------------------------------------------------

    Parameters:

        x - first integer user inputs  (int)
        y - second integer user inputs (int)

    Returns

       quadrant_Number - returns the quadrant number (String)

    -------------------------------------------------------

    """
    if (x > 0 and y > 0): 
        quadrant_Number = "Q1"
  
    elif (x < 0 and y > 0): 
        quadrant_Number = "Q2"
          
    elif (x < 0 and y < 0): 
        quadrant_Number = "Q3"
      
    elif (x > 0 and y < 0): 
        quadrant_Number = "Q4"
          
    elif (x == 0 and y > 0): 
        quadrant_Number = "Q1"
      
    elif (x == 0 and y < 0): 
        quadrant_Number = "Q3"
      
    elif (y == 0 and x < 0): 
        quadrant_Number = "Q2"
      
    elif (y == 0 and x > 0): 
        quadrant_Number = "Q4"
      
    else: 
        quadrant_Number = "Q1" 
         
    return quadrant_Number