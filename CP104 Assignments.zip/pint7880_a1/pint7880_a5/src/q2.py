"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-10"
------------------------------------------------------------------------
"""
import a2_functions

num = int(input("Enter a pocket number:"))


colour = a2_functions.pocket_color(num)

if num <= 36:
    print ("The selected pocket is {}.".format(colour))
else:
    print ("ERROR")